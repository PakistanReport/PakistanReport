---
layout: article
title: "Disposable Publisher Test 2"
category: "Pakistan"
author: "Pakistan Report Editorial Desk"
description: "Disposable technical test; not a news article."
published: true
image: "/assets/images/disposable-publisher-test-2.png"
image_alt: "Disposable test pixel"
---

This is disposable technical test content for the Pakistan Report Publisher. It is not a news report. Remove after testing.
